import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite/sqflite.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StoreDb.instance.database;
  runApp(const HesabdarApp());
}

String money(Object? value) {
  final s = (value ?? 0).toString();
  return s.replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
}

class StoreDb {
  StoreDb._();
  static final instance = StoreDb._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(p.join(dir, 'hesabdar_amir.db'),
      version: 1, onCreate: (db, version) async {
        await db.execute('''CREATE TABLE products(
          barcode TEXT PRIMARY KEY, name TEXT NOT NULL, buyPrice INTEGER NOT NULL DEFAULT 0,
          sellPrice INTEGER NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0,
          minStock INTEGER NOT NULL DEFAULT 3, expiry TEXT)''');
        await db.execute('''CREATE TABLE sales(
          id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT, productName TEXT,
          quantity INTEGER, unitPrice INTEGER, buyPrice INTEGER, total INTEGER,
          profit INTEGER, createdAt TEXT)''');
        await db.execute('''CREATE TABLE expenses(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, createdAt TEXT)''');
        await db.execute('''CREATE TABLE customers(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, balance INTEGER DEFAULT 0)''');
        await db.execute('''CREATE TABLE debts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, customerId INTEGER, customerName TEXT,
          amount INTEGER, note TEXT, createdAt TEXT)''');
      });
    return _db!;
  }

  Future<List<Map<String, Object?>>> all(String table, {String? order}) async =>
      (await database).query(table, orderBy: order);
  Future<int> count(String table) async =>
      Sqflite.firstIntValue(await (await database).rawQuery('SELECT COUNT(*) FROM $table')) ?? 0;
  Future<int> sum(String table, String col, {String? where, List<Object?>? args}) async =>
      Sqflite.firstIntValue(await (await database).rawQuery(
        'SELECT COALESCE(SUM($col),0) FROM $table ${where == null ? '' : 'WHERE $where'}', args)) ?? 0;

  Future<void> addProduct(Map<String, Object?> data) async =>
      (await database).insert('products', data, conflictAlgorithm: ConflictAlgorithm.replace);

  Future<void> sell(String barcode, int qty) async {
    final db = await database;
    await db.transaction((txn) async {
      final rows = await txn.query('products', where: 'barcode=?', whereArgs: [barcode]);
      if (rows.isEmpty) throw Exception('کالا با این بارکد ثبت نشده است');
      final item = rows.first;
      final stock = item['stock'] as int;
      if (qty < 1 || stock < qty) throw Exception('موجودی کالا کافی نیست');
      final sellPrice = item['sellPrice'] as int;
      final buyPrice = item['buyPrice'] as int;
      final total = sellPrice * qty;
      final profit = (sellPrice - buyPrice) * qty;
      await txn.update('products', {'stock': stock - qty}, where: 'barcode=?', whereArgs: [barcode]);
      await txn.insert('sales', {
        'barcode': barcode, 'productName': item['name'], 'quantity': qty,
        'unitPrice': sellPrice, 'buyPrice': buyPrice, 'total': total,
        'profit': profit, 'createdAt': DateTime.now().toIso8601String()
      });
    });
  }

  Future<void> backup() async {
    final db = await database;
    final data = <String, Object?>{};
    for (final table in ['products','sales','expenses','customers','debts']) {
      data[table] = await db.query(table);
    }
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'hesabdar_amir_backup.json'));
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    await Share.shareXFiles([XFile(file.path)], text: 'پشتیبان حسابدار امیر');
  }
}

class HesabdarApp extends StatelessWidget {
  const HesabdarApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'حسابدار امیر', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF176B55)),
    home: const MainPage(),
  );
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override State<MainPage> createState() => _MainPageState();
}
class _MainPageState extends State<MainPage> {
  int index = 0;
  int refresh = 0;
  void changed() => setState(() => refresh++);
  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(key: ValueKey('d$refresh'), onBackup: () async { await StoreDb.instance.backup(); }),
      ProductsPage(onChanged: changed),
      SalesPage(onChanged: changed),
      FinancePage(onChanged: changed),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('حسابدار امیر'), centerTitle: true,
        actions: [IconButton(tooltip: 'پشتیبان‌گیری', onPressed: () async {
          await StoreDb.instance.backup();
          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فایل پشتیبان آماده اشتراک‌گذاری است')));
        }, icon: const Icon(Icons.backup))]),
      body: pages[index],
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index=v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'کالاها'),
          NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'فروش'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'حساب‌ها'),
        ]),
    ));
  }
}

class DashboardPage extends StatelessWidget {
  final Future<void> Function() onBackup;
  const DashboardPage({super.key, required this.onBackup});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<int>>(
    future: Future.wait([StoreDb.instance.count('products'), StoreDb.instance.sum('sales','total'),
      StoreDb.instance.sum('sales','profit'), StoreDb.instance.sum('expenses','amount')]),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final v=snap.data!;
      return ListView(padding: const EdgeInsets.all(16), children: [
        Card(color: Theme.of(context).colorScheme.primaryContainer, child: const Padding(
          padding: EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('مدیریت سوپرمارکت', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text('نسخه آفلاین – اطلاعات روی همین گوشی ذخیره می‌شود'),
          ]))),
        const SizedBox(height: 12),
        GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2,
          childAspectRatio: 1.5, children: [
            Metric('تعداد کالا', '${v[0]}', Icons.inventory),
            Metric('فروش ثبت‌شده', '${money(v[1])} ریال', Icons.point_of_sale),
            Metric('سود ناخالص', '${money(v[2])} ریال', Icons.trending_up),
            Metric('هزینه‌ها', '${money(v[3])} ریال', Icons.payments),
          ]),
        const SizedBox(height: 12),
        const Text('توجه: سود نمایش‌داده‌شده اختلاف قیمت خرید و فروش کالاهاست و هزینه‌های مغازه از آن جدا هستند.'),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: onBackup, icon: const Icon(Icons.backup), label: const Text('ساخت نسخه پشتیبان')),
      ]);
    });
}
class Metric extends StatelessWidget {
  final String title, value; final IconData icon;
  const Metric(this.title,this.value,this.icon,{super.key});
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center,
      children: [Icon(icon), const SizedBox(height: 6), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        Text(title, style: const TextStyle(color: Colors.grey))])));
}

class ProductsPage extends StatefulWidget {
  final VoidCallback onChanged;
  const ProductsPage({super.key, required this.onChanged});
  @override State<ProductsPage> createState()=>_ProductsPageState();
}
class _ProductsPageState extends State<ProductsPage> {
  Future<void> add() async {
    final result=await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductForm()));
    if (result==true) { setState((){}); widget.onChanged(); }
  }
  @override Widget build(BuildContext context)=>Scaffold(
    body: FutureBuilder<List<Map<String,Object?>>>(
      future: StoreDb.instance.all('products',order:'name COLLATE NOCASE'),
      builder:(context,snap){
        if(!snap.hasData)return const Center(child:CircularProgressIndicator());
        final items=snap.data!;
        if(items.isEmpty)return const Center(child:Text('هنوز کالایی ثبت نشده است. از دکمه افزودن استفاده کن.'));
        return ListView.builder(itemCount:items.length,itemBuilder:(c,i){
          final x=items[i];
          return ListTile(leading:const CircleAvatar(child:Icon(Icons.inventory_2)),
            title:Text('${x['name']}'), subtitle:Text('بارکد: ${x['barcode']} | موجودی: ${x['stock']}'),
            trailing:Text('${money(x['sellPrice'])} ریال'));
        });
      }),
    floatingActionButton:FloatingActionButton.extended(onPressed:add,icon:const Icon(Icons.add),label:const Text('ثبت کالا')));
}

class ProductForm extends StatefulWidget {
  const ProductForm({super.key});
  @override State<ProductForm> createState()=>_ProductFormState();
}
class _ProductFormState extends State<ProductForm>{
  final name=TextEditingController(), barcode=TextEditingController(), buy=TextEditingController(text:'0'),
    sell=TextEditingController(text:'0'), stock=TextEditingController(text:'0'), min=TextEditingController(text:'3');
  Future<void> scan() async {
    final code=await Navigator.push<String>(context,MaterialPageRoute(builder:(_)=>const ScannerPage()));
    if(code!=null)setState(()=>barcode.text=code);
  }
  Widget field(String label,TextEditingController c,{bool numeric=false})=>Padding(padding:const EdgeInsets.only(bottom:12),
    child:TextField(controller:c,keyboardType:numeric?TextInputType.number:TextInputType.text,
      inputFormatters:numeric?[FilteringTextInputFormatter.digitsOnly]:null,
      decoration:InputDecoration(labelText:label,border:const OutlineInputBorder())));
  Future<void> save() async {
    if(name.text.trim().isEmpty||barcode.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('نام و بارکد الزامی است')));return;}
    await StoreDb.instance.addProduct({'barcode':barcode.text.trim(),'name':name.text.trim(),
      'buyPrice':int.tryParse(buy.text)??0,'sellPrice':int.tryParse(sell.text)??0,
      'stock':int.tryParse(stock.text)??0,'minStock':int.tryParse(min.text)??3});
    if(mounted)Navigator.pop(context,true);
  }
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
    appBar:AppBar(title:const Text('ثبت کالا')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      field('نام کالا',name),
      Row(children:[Expanded(child:field('بارکد',barcode)),IconButton(onPressed:scan,icon:const Icon(Icons.qr_code_scanner,size:32))]),
      field('قیمت خرید (ریال)',buy,numeric:true),field('قیمت فروش (ریال)',sell,numeric:true),
      field('موجودی اولیه',stock,numeric:true),field('حداقل موجودی برای هشدار',min,numeric:true),
      FilledButton(onPressed:save,child:const Text('ذخیره کالا')),
    ])));
}

class ScannerPage extends StatelessWidget {
  const ScannerPage({super.key});
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
    appBar:AppBar(title:const Text('اسکن بارکد کالا')),
    body:MobileScanner(onDetect:(capture){
      final code=capture.barcodes.isNotEmpty ? capture.barcodes.first.rawValue : null;
      if(code!=null&&code.isNotEmpty)Navigator.pop(context,code);
    })));
}

class SalesPage extends StatefulWidget {
  final VoidCallback onChanged;
  const SalesPage({super.key,required this.onChanged});
  @override State<SalesPage> createState()=>_SalesPageState();
}
class _SalesPageState extends State<SalesPage>{
  final code=TextEditingController(),qty=TextEditingController(text:'1');
  Future<void> scan()async{final v=await Navigator.push<String>(context,MaterialPageRoute(builder:(_)=>const ScannerPage()));if(v!=null)setState(()=>code.text=v);}
  Future<void> sell()async{
    try{await StoreDb.instance.sell(code.text.trim(),int.tryParse(qty.text)??1);
      code.clear();qty.text='1';widget.onChanged();setState((){});
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('فروش ثبت شد و موجودی کم شد')));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('ثبت فروش',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    const SizedBox(height:16),
    TextField(controller:code,decoration:InputDecoration(labelText:'بارکد کالا',border:const OutlineInputBorder(),
      suffixIcon:IconButton(onPressed:scan,icon:const Icon(Icons.qr_code_scanner)))),
    const SizedBox(height:12),
    TextField(controller:qty,keyboardType:TextInputType.number,inputFormatters:[FilteringTextInputFormatter.digitsOnly],
      decoration:const InputDecoration(labelText:'تعداد',border:OutlineInputBorder())),
    const SizedBox(height:16),FilledButton.icon(onPressed:sell,icon:const Icon(Icons.check),label:const Text('ثبت فروش')),
    const SizedBox(height:24),const Text('آخرین فروش‌ها',style:TextStyle(fontWeight:FontWeight.bold)),
    FutureBuilder<List<Map<String,Object?>>>(future:StoreDb.instance.all('sales',order:'id DESC'),builder:(c,s){
      if(!s.hasData)return const LinearProgressIndicator();
      final rows=s.data!.take(10).toList();
      return Column(children:rows.map((x)=>ListTile(title:Text('${x['productName']} × ${x['quantity']}'),
        subtitle:Text('${x['createdAt']}'),trailing:Text('${money(x['total'])} ریال'))).toList());
    })
  ]);
}

class FinancePage extends StatefulWidget {
  final VoidCallback onChanged;
  const FinancePage({super.key,required this.onChanged});
  @override State<FinancePage> createState()=>_FinancePageState();
}
class _FinancePageState extends State<FinancePage>{
  Future<void> addExpense()async{
    final title=TextEditingController(),amount=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('ثبت هزینه'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:title,decoration:const InputDecoration(labelText:'شرح هزینه')),
        TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مبلغ به ریال'))]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('انصراف')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('ذخیره'))]));
    if(ok==true&&title.text.trim().isNotEmpty){
      await (await StoreDb.instance.database).insert('expenses',{'title':title.text.trim(),
        'amount':int.tryParse(amount.text)??0,'createdAt':DateTime.now().toIso8601String()});
      setState((){});widget.onChanged();
    }
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('هزینه‌های مغازه',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),FilledButton.icon(onPressed:addExpense,icon:const Icon(Icons.add),label:const Text('ثبت هزینه جدید')),
    const SizedBox(height:16),
    FutureBuilder<List<Map<String,Object?>>>(future:StoreDb.instance.all('expenses',order:'id DESC'),builder:(c,s){
      if(!s.hasData)return const CircularProgressIndicator();
      if(s.data!.isEmpty)return const Text('هنوز هزینه‌ای ثبت نشده است.');
      return Column(children:s.data!.map((x)=>ListTile(title:Text('${x['title']}'),
        subtitle:Text('${x['createdAt']}'),trailing:Text('${money(x['amount'])} ریال'))).toList());
    }),
    const SizedBox(height:20),
    const Text('گزارش فروش و سود',style:TextStyle(fontWeight:FontWeight.bold)),
    FutureBuilder<List<int>>(future:Future.wait([StoreDb.instance.sum('sales','total'),
      StoreDb.instance.sum('sales','profit'),StoreDb.instance.sum('expenses','amount')]),
      builder:(c,s)=>s.hasData?Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[
        ListTile(title:const Text('مجموع فروش'),trailing:Text('${money(s.data![0])} ریال')),
        ListTile(title:const Text('سود ناخالص'),trailing:Text('${money(s.data![1])} ریال')),
        ListTile(title:const Text('مجموع هزینه‌ها'),trailing:Text('${money(s.data![2])} ریال')),
        ListTile(title:const Text('سود پس از هزینه‌های ثبت‌شده'),trailing:Text('${money(s.data![1]-s.data![2])} ریال')),
      ]))):const LinearProgressIndicator()),
  ]);
}
